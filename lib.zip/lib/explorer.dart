class Explorer{
  String name;
  String age;

//classe molde para fazer varios exploradores
  Explorer({required this.name, required this.age});

}