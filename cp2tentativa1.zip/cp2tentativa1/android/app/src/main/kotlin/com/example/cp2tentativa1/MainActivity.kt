package com.example.cp2tentativa1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
