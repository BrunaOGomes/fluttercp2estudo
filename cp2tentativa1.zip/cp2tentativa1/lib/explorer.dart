//define o pai e seus parametros
class Explorer {
  String name;
  String age;

  Explorer({required this.name, required this.age});
}
